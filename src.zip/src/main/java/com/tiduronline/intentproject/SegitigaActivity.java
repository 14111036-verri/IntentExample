package com.tiduronline.intentproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class SegitigaActivity extends MainActivity {

    Double hasil = 0.0;
    Double alas = 0.0;
    Double tinggi = 0.0;
    Double luas = 0.0;
    Double keliling = 0.0;
    Double powAlas = 0.0;
    Double powTinggi = 0.0;
    Double miring = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segitiga);
        initElement();
        initBtnGotoHome();
        initBtnClear();

        hitungBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hitung();
            }
        });
    }


    public void hitung() {
        try {
            alas = Double.parseDouble(alasTxt.getText().toString());
            tinggi = Double.parseDouble(tinggiTxt.getText().toString());
        } catch(Exception e) {
            Log.i("TIDURONLINE", e.toString());
        }

        luas = luas();
        keliling = keliling();
        setValues(luas, keliling);
    }


    protected Double luas() {
        hasil = 0.5 * (this.alas * this.tinggi);
        return hasil;
    }


    protected Double keliling() {
        powAlas = Math.pow(alas, 2);
        powTinggi = Math.pow(tinggi, 2);

        miring = Math.sqrt(powAlas + powTinggi);


        return alas+tinggi+miring;
    }

}
