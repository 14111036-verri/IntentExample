package com.tiduronline.intentproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button gotoPersegi, gotoSegitiga, homeBtn, clearBtn, hitungBtn;
    EditText sisiTxt, alasTxt, tinggiTxt;
    TextView hasilLuasTxt, hasilKelilingTxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initElement();

        gotoPersegi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intPersegi = new Intent(v.getContext(), PersegiActivity.class);
                startActivity(intPersegi);
            }
        });

        gotoSegitiga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intSegitiga = new Intent(v.getContext(), SegitigaActivity.class);
                startActivity(intSegitiga);
            }
        });
    }

    protected void initElement() {
        gotoPersegi = (Button) findViewById(R.id.gotoPersegi);
        gotoSegitiga = (Button) findViewById(R.id.gotoSegitiga);
        sisiTxt = (EditText) findViewById(R.id.sisiTxt);
        alasTxt = (EditText) findViewById(R.id.alasTxt);
        tinggiTxt = (EditText) findViewById(R.id.tinggiTxt);
        hasilKelilingTxt = (TextView) findViewById(R.id.hasilKelilingTxt);
        hasilLuasTxt = (TextView) findViewById(R.id.hasilLuasTxt);
        homeBtn = (Button) findViewById(R.id.homeBtn);
        hitungBtn = (Button) findViewById(R.id.hitungBtn);
    }


    protected void initBtnGotoHome() {
        homeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    protected void initBtnClear() {
        clearBtn = (Button) findViewById(R.id.clearBtn);
        clearBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                clearInput();
            }
        });
    }

    protected void clearInput() {
        try {
            sisiTxt.setText("");
        }  catch (Exception e) {
            alasTxt.setText("");
            tinggiTxt.setText("");
        }

        hasilLuasTxt.setText("");
        hasilKelilingTxt.setText("");
    }

    protected void setValues(Double luas, Double keliling) {
        hasilLuasTxt.setText(String.format("%.2f", luas));
        hasilKelilingTxt.setText(String.format("%.2f", keliling));
    }
}
