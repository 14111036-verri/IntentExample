package com.tiduronline.intentproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class PersegiActivity extends MainActivity {
    Double sisi = 0.0;
    Double luas = 0.0;
    Double keliling = 0.0;
    Double hasil = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_persegi);
        initElement();
        initBtnGotoHome();
        initBtnClear();

        hitungBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hitung();
            }
        });
    }

    public void hitung() {
        try {
            sisi = Double.parseDouble(sisiTxt.getText().toString());
        } catch(Exception e) {
            Log.i("TIDURONLINE", e.toString());
        }

        luas = luas();
        keliling = keliling();

        setValues(luas, keliling);
    }

    protected Double luas() {
        hasil = sisi*sisi;
        return hasil;
    }


    protected Double keliling() {
        return 4*sisi;
    }
}
